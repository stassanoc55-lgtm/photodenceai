package com.photodance.ai

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var photoPreview: ImageView
    private lateinit var musicText: TextView
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private var photoUri: Uri? = null
    private var musicUri: Uri? = null

    companion object {
        private const val PHOTO_REQUEST = 100
        private const val MUSIC_REQUEST = 101
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        photoPreview = findViewById(R.id.photoPreview)
        musicText = findViewById(R.id.musicText)
        status = findViewById(R.id.status)
        progress = findViewById(R.id.progress)

        findViewById<Button>(R.id.selectPhoto).setOnClickListener {
            openPicker("image/*", PHOTO_REQUEST)
        }
        findViewById<Button>(R.id.selectMusic).setOnClickListener {
            openPicker("audio/*", MUSIC_REQUEST)
        }
        findViewById<Button>(R.id.createVideo).setOnClickListener {
            prepareVideoRequest()
        }
    }

    private fun openPicker(type: String, requestCode: Int) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            this.type = type
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(intent, requestCode)
    }

    @Deprecated("Prototype 0.1")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data?.data == null) return
        val uri = data.data!!

        if (requestCode == PHOTO_REQUEST) {
            photoUri = uri
            photoPreview.setImageURI(uri)
            photoPreview.visibility = View.VISIBLE
            status.text = "Фото выбрано ✓"
        } else if (requestCode == MUSIC_REQUEST) {
            musicUri = uri
            musicText.text = "✓ ${getFileName(uri)}"
            status.text = "Музыка выбрана ✓"
        }
    }

    private fun getFileName(uri: Uri): String {
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && index >= 0) return cursor.getString(index)
        }
        return "аудиофайл"
    }

    private fun prepareVideoRequest() {
        if (photoUri == null) {
            status.text = "Сначала выбери фотографию."
            return
        }
        if (musicUri == null) {
            status.text = "Выбери музыку."
            return
        }

        val style = findViewById<Spinner>(R.id.danceStyle).selectedItem.toString()
        val prompt = "Realistic continuous full-body dance. Style: $style. " +
                "Preserve identity, face, hairstyle and clothing. Natural arms, legs, " +
                "shoulders and torso. Realistic hands and feet. Natural hair and clothing " +
                "movement. Photorealistic anatomy. No slideshow, cuts, morphing or duplicated limbs."

        progress.visibility = View.VISIBLE
        status.text = "Подготавливаю AI-видео…"

        android.os.Handler(mainLooper).postDelayed({
            progress.visibility = View.GONE
            status.text = "Задание подготовлено ✓\n\n$prompt"
        }, 1200)
    }
}
